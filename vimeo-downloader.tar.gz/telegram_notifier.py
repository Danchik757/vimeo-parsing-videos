"""
Telegram notifications module for Vimeo downloader
Sends notifications about download progress, errors, and status
"""

import requests
import logging
from datetime import datetime

logger = logging.getLogger(__name__)


class TelegramNotifier:
    """Send notifications via Telegram Bot API"""

    def __init__(self, config):
        """
        Initialize Telegram notifier

        Args:
            config: Configuration dictionary with telegram settings
        """
        self.enabled = config.get('telegram', {}).get('enabled', False)
        self.bot_token = config.get('telegram', {}).get('bot_token', '')
        self.chat_id = config.get('telegram', {}).get('chat_id', '')
        self.notify_every_n = config.get('telegram', {}).get('notify_every_n_videos', 1)
        self.notify_on_start = config.get('telegram', {}).get('notify_on_start', True)
        self.notify_on_finish = config.get('telegram', {}).get('notify_on_finish', True)
        self.notify_on_error = config.get('telegram', {}).get('notify_on_error', True)
        self.notify_on_ip_block = config.get('telegram', {}).get('notify_on_ip_block', True)

        # Validate configuration
        if self.enabled and (not self.bot_token or not self.chat_id):
            logger.warning("Telegram enabled but bot_token or chat_id is missing. Disabling notifications.")
            self.enabled = False

        if self.enabled:
            logger.info(f"Telegram notifications enabled (chat_id: {self.chat_id})")

    def send_message(self, text, parse_mode='HTML'):
        """
        Send message to Telegram chat

        Args:
            text: Message text
            parse_mode: Telegram parse mode (HTML or Markdown)

        Returns:
            bool: True if sent successfully, False otherwise
        """
        if not self.enabled:
            return False

        url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
        payload = {
            'chat_id': self.chat_id,
            'text': text,
            'parse_mode': parse_mode,
            'disable_web_page_preview': True
        }

        try:
            response = requests.post(url, json=payload, timeout=10)
            if response.status_code == 200:
                logger.debug(f"Telegram message sent: {text[:50]}...")
                return True
            else:
                logger.error(f"Failed to send Telegram message: {response.status_code} - {response.text}")
                return False
        except Exception as e:
            logger.error(f"Error sending Telegram message: {e}")
            return False

    def notify_start(self, total_videos, test_mode=False):
        """Notify about download session start"""
        if not self.enabled or not self.notify_on_start:
            return

        mode = "ТЕСТОВЫЙ РЕЖИМ" if test_mode else "ПОЛНЫЙ РЕЖИМ"
        text = f"""
🚀 <b>Vimeo Downloader ЗАПУЩЕН</b>

📊 Режим: {mode}
📹 Всего видео: {total_videos:,}
🕐 Время старта: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Начинаю обработку...
"""
        self.send_message(text)

    def notify_video_downloaded(self, video_id, filename, file_size_mb, current_num, total_videos):
        """Notify about successful video download"""
        if not self.enabled:
            return

        # Only send notification every N videos
        if current_num % self.notify_every_n != 0:
            return

        progress = (current_num / total_videos) * 100
        text = f"""
✅ <b>Видео скачано #{current_num}</b>

🎬 ID: <code>{video_id}</code>
📁 Файл: <code>{filename}</code>
💾 Размер: {file_size_mb:.1f} MB
📊 Прогресс: {current_num}/{total_videos} ({progress:.1f}%)

⏰ {datetime.now().strftime('%H:%M:%S')}
"""
        self.send_message(text)

    def notify_video_skipped(self, video_id, reason, current_num, total_videos):
        """Notify about skipped video"""
        if not self.enabled:
            return

        # Only send for every N videos to avoid spam
        if current_num % self.notify_every_n != 0:
            return

        text = f"""
⏭ <b>Видео пропущено #{current_num}</b>

🎬 ID: <code>{video_id}</code>
⚠️ Причина: {reason}
📊 Прогресс: {current_num}/{total_videos}

⏰ {datetime.now().strftime('%H:%M:%S')}
"""
        self.send_message(text)

    def notify_error(self, video_id, error_message, current_num, total_videos):
        """Notify about download error"""
        if not self.enabled or not self.notify_on_error:
            return

        text = f"""
❌ <b>ОШИБКА при скачивании</b>

🎬 ID: <code>{video_id}</code>
⚠️ Ошибка: <code>{error_message[:200]}</code>
📊 Прогресс: {current_num}/{total_videos}

⏰ {datetime.now().strftime('%H:%M:%S')}
"""
        self.send_message(text)

    def notify_ip_blocked(self, ip_address, reason):
        """Notify about IP blocking"""
        if not self.enabled or not self.notify_on_ip_block:
            return

        text = f"""
🚫 <b>IP ЗАБЛОКИРОВАН</b>

🌐 IP: <code>{ip_address}</code>
⚠️ Причина: {reason}
⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        self.send_message(text)

    def notify_finish(self, stats):
        """
        Notify about download session completion

        Args:
            stats: Dictionary with download statistics
        """
        if not self.enabled or not self.notify_on_finish:
            return

        total = stats.get('total', 0)
        downloaded = stats.get('downloaded', 0)
        skipped = stats.get('skipped', 0)
        failed = stats.get('failed', 0)
        ip_blocked = stats.get('ip_blocked', False)

        status_icon = "🚫" if ip_blocked else "✅"
        status_text = "ОСТАНОВЛЕН (IP блокировка)" if ip_blocked else "ЗАВЕРШЕН"

        text = f"""
{status_icon} <b>Vimeo Downloader {status_text}</b>

📊 <b>Статистика:</b>
📹 Всего обработано: {total}
✅ Скачано: {downloaded}
⏭ Пропущено: {skipped}
❌ Ошибок: {failed}

⏰ Время завершения: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        self.send_message(text)

    def notify_api_error(self, error_code, error_message):
        """Notify about API errors (401, 403, 429)"""
        if not self.enabled or not self.notify_on_error:
            return

        text = f"""
🚨 <b>ОШИБКА API</b>

⚠️ Код: {error_code}
📝 {error_message}
⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        self.send_message(text)


def test_telegram_connection(config):
    """
    Test Telegram bot connection

    Args:
        config: Configuration dictionary

    Returns:
        bool: True if test successful, False otherwise
    """
    notifier = TelegramNotifier(config)

    if not notifier.enabled:
        print("❌ Telegram notifications disabled in config")
        return False

    test_message = f"""
🧪 <b>Тестовое сообщение</b>

✅ Telegram бот настроен корректно!
⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

Уведомления будут приходить:
• При старте скачивания
• Каждые {notifier.notify_every_n} видео
• При ошибках
• При блокировке IP
• При завершении работы
"""

    success = notifier.send_message(test_message)

    if success:
        print("✅ Тестовое сообщение отправлено успешно!")
        print(f"📱 Проверьте Telegram чат: {notifier.chat_id}")
    else:
        print("❌ Не удалось отправить тестовое сообщение")
        print("   Проверьте bot_token и chat_id в config.json")

    return success


if __name__ == "__main__":
    # Test mode - send test message
    import json

    print("Тестирование Telegram уведомлений...")
    print()

    try:
        with open('config.json', 'r') as f:
            config = json.load(f)

        test_telegram_connection(config)

    except FileNotFoundError:
        print("❌ config.json не найден")
    except Exception as e:
        print(f"❌ Ошибка: {e}")
